"""Numerical evaluation helpers (real-valued, branch aware)."""
from __future__ import annotations

import numpy as np

from .. import safe_math as sm

real_rational_power = sm.real_rational_power


def sample(expr, lo: float, hi: float, n: int = 3001) -> tuple[np.ndarray, np.ndarray]:
    xs = np.linspace(lo, hi, n)
    return xs, sm.to_numpy(expr)(xs)


def split_branches(xs: np.ndarray, ys: np.ndarray, poles: list[float], jump: float) -> list[tuple[np.ndarray, np.ndarray]]:
    """Continuous finite pieces of the sampled graph (split at NaN, poles and big jumps)."""
    out, cur_x, cur_y = [], [], []
    for i in range(len(xs)):
        brk = not np.isfinite(ys[i])
        if not brk and cur_x:
            if abs(ys[i] - cur_y[-1]) > jump or any(cur_x[-1] < p < xs[i] for p in poles):
                brk = True
                out.append((np.array(cur_x), np.array(cur_y)))
                cur_x, cur_y = [], []
        if brk and not np.isfinite(ys[i]):
            if cur_x:
                out.append((np.array(cur_x), np.array(cur_y)))
            cur_x, cur_y = [], []
            continue
        cur_x.append(xs[i]); cur_y.append(ys[i])
    if cur_x:
        out.append((np.array(cur_x), np.array(cur_y)))
    return [b for b in out if len(b[0]) >= 3]
