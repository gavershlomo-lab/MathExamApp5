"""Graph engine: formula graphs (exact math), qualitative graphs (topology only) and multiple-choice graph sets."""
