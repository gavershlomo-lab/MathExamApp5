"""Teacher review state. An approval is bound to the exact spec (hash); any change voids it."""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone

from .schemas import DiagramRecord, DiagramSpec, ReviewState, TeacherEdit


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def spec_hash(spec: DiagramSpec | None) -> str:
    if spec is None:
        return ""
    data = spec.model_dump_json(exclude={"warnings", "source_image_hash"})
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def initial_review(record: DiagramRecord, prior: ReviewState | None, allow_auto: bool = False) -> ReviewState:
    """allow_auto is accepted for v5.4 compatibility and IGNORED: nothing is approved without a teacher."""
    h = spec_hash(record.spec)
    if prior is not None and prior.spec_hash == h and prior.status in ("approved", "rejected", "original"):
        return prior.model_copy(deep=True)
    review = ReviewState(status="pending", spec_hash=h, updated_at=now(),
                         teacher_edits=list(prior.teacher_edits) if prior else [])
    if record.decision.action == "original":
        review.status = "original"
    return review


def can_approve(record: DiagramRecord) -> bool:
    return record.validation.ok and not record.comparison.critical and record.decision.action != "original" and not record.render_error


def approve(record: DiagramRecord) -> bool:
    if not can_approve(record):
        return False
    record.review.status, record.review.approved_by = "approved", "teacher"
    record.review.spec_hash, record.review.updated_at = spec_hash(record.spec), now()
    return True


def use_original(record: DiagramRecord) -> None:
    record.review.status, record.review.approved_by, record.review.updated_at = "original", "", now()


def reject(record: DiagramRecord) -> None:
    record.review.status, record.review.approved_by, record.review.updated_at = "rejected", "", now()


def usable_in_document(record: DiagramRecord | None) -> bool:
    """THE export gate: teacher-approved AND bound to this exact spec AND valid AND no critical mismatch."""
    return bool(record and record.review.status == "approved" and record.review.approved_by == "teacher"
                and record.review.spec_hash == spec_hash(record.spec) and can_approve(record))


def add_edit(review: ReviewState, summary: str, before: str, after: str) -> None:
    review.teacher_edits.append(TeacherEdit(at=now(), summary=summary, spec_hash_before=before, spec_hash_after=after))
