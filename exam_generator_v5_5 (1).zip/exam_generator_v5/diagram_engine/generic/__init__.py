"""Generic schematic diagrams: rectangles/polygons/lines/arrows/dimension lines/labels, with adjacency preserved."""
