"""Central constants of the diagram engine (versions, policy thresholds, concurrency)."""
from __future__ import annotations

SCHEMA_VERSION = "2.0"
PARSER_VERSION = "diagram-engine/2.0"

# Confidence policy (decision.py). Nothing is ever exported automatically: HIGH_CONFIDENCE_PREVIEW still needs a teacher.
HIGH_CONFIDENCE = 0.94
REVIEW_CONFIDENCE = 0.85
DRAFT_CONFIDENCE = 0.70
IMAGE_ONLY_CAP = 0.90          # facts read only from pixels can never reach HIGH_CONFIDENCE
QUALITATIVE_CAP = 0.93         # topology sketches (no equation) never reach HIGH_CONFIDENCE

MAX_DIAGRAM_WORKERS = 3
RENDER_CACHE_SIZE = 128

# Reliability hierarchy of evidence sources (higher wins in a conflict).
SOURCE_RANK = {
    "teacher": 7,
    "question_text": 6,
    "diagram_symbol": 5,
    "deterministic_detection": 4,
    "derived_math": 4,
    "ocr": 3,
    "vision": 2,
    "visual_appearance": 1,
}
# Sources allowed to create a geometric RELATION (drawings are often not to scale).
RELATION_SOURCES = {"teacher", "question_text", "diagram_symbol", "deterministic_detection", "derived_math"}
