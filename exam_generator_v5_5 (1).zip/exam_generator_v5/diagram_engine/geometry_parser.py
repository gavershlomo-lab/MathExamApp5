"""Backward-compatible shim (v5.4 import path)."""
from .geometry.parser import marks_to_constraints, merge_text, relations_from_text  # noqa: F401
