"""Charts and tables: bar/line/histogram/pie, scatter (with deterministic dot detection), normal-distribution
schematic, native tables."""
