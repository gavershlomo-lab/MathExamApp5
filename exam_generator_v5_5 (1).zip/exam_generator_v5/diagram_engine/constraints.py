"""Backward-compatible shim (v5.4 import path)."""
from .geometry.constraints import residuals, size_of  # noqa: F401
from .geometry.solver import TOL, solve  # noqa: F401
