"""Backward-compatible shim (v5.4 import path)."""
from .graph.renderer import render  # noqa: F401
