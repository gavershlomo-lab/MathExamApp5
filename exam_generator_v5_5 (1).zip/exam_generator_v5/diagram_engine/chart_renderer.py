"""Backward-compatible shim (v5.4 import path)."""
from .charts.renderer import render, render_generic  # noqa: F401
