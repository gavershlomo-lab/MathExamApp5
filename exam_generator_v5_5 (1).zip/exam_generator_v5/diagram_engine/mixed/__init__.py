"""Mixed graph + geometry in one coordinate system (e.g. semicircle y=sqrt(R^2-x^2) with an inscribed rectangle,
circle on the coordinate plane with a tangent)."""
