"""Layout solver: moves image-derived coordinates as little as possible so every constraint holds exactly.
Fixed points (exact coordinates from the text) are not variables. Unknown circle centres are hidden variables."""
from __future__ import annotations

import itertools
from typing import Callable

import numpy as np

from ..schemas import GeometrySpec, GPoint
from .constraints import _cross, residuals, size_of

TOL = 1e-7


def add_hidden_centres(geo: GeometrySpec) -> None:
    """A circle given only by points on it gets a hidden centre (initial guess: circumcentre of 3 of its points)."""
    ids = {p.id for p in geo.points}
    P = {p.id: np.array([p.x, p.y]) for p in geo.points}
    for i, c in enumerate(geo.circles):
        if c.center:
            continue
        if not c.id:
            c.id = f"circle_{i + 1}"
        hid = f"__c_{c.id}"
        if hid in ids:
            continue
        pts = [P[k] for k in c.through_points if k in P][:3]
        if len(pts) >= 3:
            a, b, cc = pts
            d = 2 * (a[0] * (b[1] - cc[1]) + b[0] * (cc[1] - a[1]) + cc[0] * (a[1] - b[1]))
            if abs(d) > 1e-12:
                ux = ((a @ a) * (b[1] - cc[1]) + (b @ b) * (cc[1] - a[1]) + (cc @ cc) * (a[1] - b[1])) / d
                uy = ((a @ a) * (cc[0] - b[0]) + (b @ b) * (a[0] - cc[0]) + (cc @ cc) * (b[0] - a[0])) / d
                guess = (float(ux), float(uy))
            else:
                guess = tuple(np.mean(pts, axis=0))
        elif pts:
            guess = tuple(np.mean(pts, axis=0) + 0.01)
        else:
            continue
        geo.points.append(GPoint(id=hid, x=guess[0], y=guess[1], label="", hidden=True, source="computed"))


def circle_membership(geo: GeometrySpec) -> list:
    """Implicit constraints: every point listed in circle.through_points lies on that circle."""
    from ..schemas import GConstraint

    out = []
    for i, c in enumerate(geo.circles):
        cid = c.id or c.center
        for k in c.through_points:
            if k != c.through:
                out.append(GConstraint(type="on_circle", points=[k, c.center or f"__c_{c.id}"], circle=cid, source="image"))
    return out


def solve(geo: GeometrySpec, curves: dict[str, Callable] | None = None) -> dict:
    add_hidden_centres(geo)
    ids = [p.id for p in geo.points]
    var = [p.id for p in geo.points if not p.fixed]
    fixed = {p.id: np.array([p.x, p.y], float) for p in geo.points if p.fixed}
    x0 = np.array([[p.x, p.y] for p in geo.points if not p.fixed], float).ravel()
    S = size_of(geo)
    cons = [c for c in geo.constraints + circle_membership(geo) if all(q in ids for q in c.points) and c.type != "fixed"]

    def unpack(x: np.ndarray) -> dict[str, np.ndarray]:
        P = dict(fixed)
        P.update({pid: x[2 * i:2 * i + 2] for i, pid in enumerate(var)})
        return P

    def F(x: np.ndarray, w: float) -> np.ndarray:
        P = unpack(x)
        r: list[float] = []
        for c in cons:
            r.extend(residuals(c, P, geo, S, curves))
        if w > 0:
            r.extend(list(w * (x - x0) / S))
        return np.array(r, float)

    x = x0.copy()
    if cons and len(x):
        for w in (1e-1, 1e-2, 1e-3, 1e-4, 0.0):
            for _ in range(60):
                r = F(x, w)
                if not len(r):
                    break
                h = 1e-7 * S
                J = np.empty((len(r), len(x)))
                for j in range(len(x)):
                    xp = x.copy()
                    xp[j] += h
                    J[:, j] = (F(xp, w) - r) / h
                dx, *_ = np.linalg.lstsq(J, -r, rcond=None)
                x = x + dx
                if np.linalg.norm(dx) < 1e-12 * S:
                    break
    P = unpack(x)
    res = {f"{c.type}:{''.join(c.points)}": max(abs(v) for v in residuals(c, P, geo, S, curves)) for c in cons}
    max_res = max(res.values()) if res else 0.0
    moved = float(np.max(np.hypot(*(x - x0).reshape(-1, 2).T))) / S if len(x) else 0.0
    P0 = {p.id: np.array([p.x, p.y], float) for p in geo.points}
    visible = [p.id for p in geo.points if not p.hidden]
    flips = []
    for a, b, c in itertools.combinations(visible, 3):
        c0 = _cross(P0[b] - P0[a], P0[c] - P0[a])
        c1 = _cross(P[b] - P[a], P[c] - P[a])
        if abs(c0) > 0.02 * S * S and abs(c1) > 0.02 * S * S and c0 * c1 < 0:   # moved ONTO a line is not a flip
            flips.append(f"{c} עברה לצד השני של הישר {a}{b}")
    return {"points": {k: (float(v[0]), float(v[1])) for k, v in P.items()}, "ok": max_res < TOL,
            "max_residual": max_res, "residuals": res, "moved_fraction": moved, "flips": flips}
