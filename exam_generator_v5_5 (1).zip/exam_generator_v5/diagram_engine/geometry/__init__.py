"""Geometry engine v2: parser (text/marks -> constraints), constraint residuals, solver, incidence checks, renderer."""
