"""Backward-compatible shim (v5.4 import path)."""
from .geometry.renderer import draw_geometry, render  # noqa: F401
