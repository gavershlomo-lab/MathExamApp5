"""Backward-compatible shim (v5.4 import path)."""
from .graph.feature_detector import add_computed_holes, features  # noqa: F401
from .graph.formula_parser import functions_from_text, merge_text  # noqa: F401
