"""Diagram pipeline v2 - ONE entry point per figure. Never raises: any failure means 'use the original'.

SOURCE -> preprocess -> structured evidence (vision JSON + question text) -> DiagramSpec -> schema validation ->
text/marks merge -> constraint solving -> deterministic validation -> deterministic renderer -> source comparison ->
decision -> teacher review -> (approved) export."""
from __future__ import annotations

import io
import json
import logging
import zipfile
from dataclasses import dataclass, field
from threading import Lock
from typing import Any

from . import audit, cache, safe_math as sm
from .charts import parser as chart_parser
from .charts import scatter as scatter_mod
from .classifier import classify
from .comparison import compare
from .decision import DEFAULT_POLICY, Policy, decide, parser_confidence
from .evidence import ev
from .geometry import parser as geometry_parser
from .geometry.solver import solve as solve_geometry
from .graph import feature_detector, formula_parser
from .mixed import parser as mixed_parser
from .mixed import solver as mixed_solver
from .preprocess import cleaned_png, image_hash
from .review_state import add_edit, initial_review, spec_hash
from .schemas import PARSER_VERSION, ComparisonResult, Decision, DiagramRecord, DiagramSpec, ReviewState, ValidationResult
from .validator import validate

log = logging.getLogger("diagram_engine")
_RENDER_LOCK = Lock()   # matplotlib rcParams are global: renders from parallel question workers must not interleave
MSG_ORIGINAL = "שחזור השרטוט לא אושר — במסמך ישולב השרטוט המקורי."


# ------------------------------------------------------------------ parsing (incl. legacy format of 5.x)
def _legacy_to_spec(data: dict, figure_type: str, confidence: float) -> dict:
    if figure_type == "function_graph" or "objects" in data and any(o.get("type") == "function" for o in data.get("objects", [])):
        xr, yr = data.get("x_range", [-10, 10]), data.get("y_range", [-10, 10])
        curves, points = [], []
        for i, o in enumerate(data.get("objects", [])):
            if o.get("type") == "function":
                curves.append({"id": f"c{i}", "label": o.get("label", ""), "expression": o.get("expression", "")})
            elif o.get("type") == "point":
                points.append({"name": o.get("label", ""), "x": o.get("x", 0), "y": o.get("y", 0)})
        return {"diagram_type": "graph", "confidence": confidence,
                "graph": {"axes": {"x_min": xr[0], "x_max": xr[1], "y_min": yr[0], "y_max": yr[1]}, "curves": curves, "points": points}}
    if figure_type == "geometry":
        geo: dict[str, Any] = {"points": [], "segments": [], "circles": [], "angle_marks": [], "length_labels": []}
        for o in data.get("objects", []):
            t = o.get("type")
            if t == "point":
                geo["points"].append({"id": o.get("label", ""), "x": o.get("x", 0), "y": o.get("y", 0)})
            elif t == "segment":
                geo["segments"].append({"a": o.get("from"), "b": o.get("to")})
            elif t == "polygon":
                v = o.get("vertices", [])
                geo["segments"] += [{"a": v[i], "b": v[(i + 1) % len(v)]} for i in range(len(v))]
            elif t == "circle":
                geo["circles"].append({"center": o.get("center"), "radius": o.get("radius")})
            elif t == "length_label":
                geo["length_labels"].append({"a": o.get("from"), "b": o.get("to"), "text": o.get("text", "")})
            elif t == "angle_mark" and len(o.get("arms", [])) == 2:
                val = str(o.get("text", ""))
                kind = "right" if val.strip() in ("90", "90°") else "arc"
                geo["angle_marks"].append({"vertex": o["vertex"], "a": o["arms"][0], "b": o["arms"][1], "kind": kind,
                                           "value": "" if kind == "right" else val})
        return {"diagram_type": "geometry", "confidence": confidence, "geometry": geo}
    if figure_type in ("bar_chart", "line_chart", "pie_chart"):
        kind = {"bar_chart": "bar", "line_chart": "line", "pie_chart": "pie"}[figure_type]
        return {"diagram_type": "chart", "confidence": confidence,
                "chart": {"kind": kind, "categories": data.get("categories") or data.get("labels") or [], "values": data.get("values", []),
                          "title": data.get("title", ""), "show_percentages": bool(data.get("show_percentages"))}}
    return {"diagram_type": "unknown", "confidence": 0.0}


def parse_raw(raw: str, figure_type: str = "", fallback_confidence: float = 0.0) -> DiagramSpec:
    data = json.loads(raw) if raw and raw.strip() else {}
    if not isinstance(data, dict):
        raise ValueError("ה-JSON של השרטוט אינו אובייקט")
    if "diagram_type" not in data:
        data = _legacy_to_spec(data, figure_type, fallback_confidence)
    return DiagramSpec.model_validate(data)


# ------------------------------------------------------------------ rendering (cached by spec hash, serialised)
def _renderer(spec: DiagramSpec):
    t, st = spec.diagram_type, spec.subtype
    if t == "graph":
        from .graph.renderer import render
        return render
    if t == "geometry":
        from .geometry.renderer import render
        return render
    if t == "mixed_graph_geometry":
        from .mixed.renderer import render
        return render
    if t == "chart" and st == "scatter_plot":
        from .charts.renderer import render_scatter
        return render_scatter
    if t == "chart" and st == "normal_distribution_schematic":
        from .charts.normal_distribution import render as r
        return lambda sp: r(sp.normal)
    if t == "chart":
        from .charts.renderer import render
        return render
    if t == "table":
        from .charts.table import render as r
        return lambda sp: r(sp.table)
    if t == "generic":
        from .generic.renderer import render
        return render
    if t == "spatial":
        from .spatial.renderer import render
        return render
    raise ValueError("אין מנוע שרטוט לסוג זה")


def render_spec(spec: DiagramSpec) -> tuple[str, bytes, dict]:
    fn = _renderer(spec)

    def run() -> tuple[str, bytes, dict]:
        with _RENDER_LOCK:
            return fn(spec)

    return cache.RENDER.get_or_compute(cache.key("render", spec_hash(spec), spec.diagram_type, spec.subtype), run)


# ------------------------------------------------------------------ evidence
def _evidence(spec: DiagramSpec) -> list:
    out = [ev("ocr", "label", l.text, l.confidence, bbox=l.bbox or None, ambiguous=l.ambiguous, alternatives=l.alternatives)
           for l in spec.labels]
    geo = spec.geometry or (spec.mixed.geometry if spec.mixed else None)
    if geo is not None:
        out += [ev(c.source, "relation", {"type": c.type, "points": c.points, "value": c.value}) for c in geo.constraints]
        out += [ev("text", "coordinate", {"key": p.id, "xy": [p.x, p.y]}) for p in geo.points if p.fixed]
    g = spec.graph or (spec.mixed.graph if spec.mixed else None)
    if g is not None:
        out += [ev(c.source, "equation", {"key": c.id, "expr": c.expression}, c.confidence) for c in g.curves if c.expression]
    obs = {k: v for k, v in spec.observed.model_dump().items() if v is not None}
    if obs:
        out.append(ev("vision", "source_signature", obs, spec.confidence))
    return out


# ------------------------------------------------------------------ main entry
def process(figure_id: str, raw_spec_json: str, question_text: str, source_png: bytes | None, *,
            figure_type_hint: str = "", fallback_confidence: float = 0.0, ai_model: str = "",
            prior_review: ReviewState | None = None, allow_auto: bool = False, teacher_spec: DiagramSpec | None = None,
            policy: Policy = DEFAULT_POLICY) -> DiagramRecord:
    """allow_auto is accepted for v5.4 compatibility and ignored (no automatic export exists any more)."""
    rec = DiagramRecord(figure_id=figure_id, raw_spec_json=raw_spec_json or "")
    try:
        spec = teacher_spec.model_copy(deep=True) if teacher_spec is not None else parse_raw(raw_spec_json, figure_type_hint, fallback_confidence)
        spec.source_image_hash = image_hash(source_png or b"")
        spec.parser_version = PARSER_VERSION
        rec.spec = spec
        ctype, cconf, creasons = classify(spec, question_text)
        rec.classifier_type, rec.classifier_subtype, rec.classifier_confidence = ctype, spec.subtype or "", cconf
        if ctype == "unknown":
            rec.validation.errors = creasons or ["סוג התרשים לא זוהה"]
            rec.decision = Decision(action="original", reasons=creasons)
            rec.teacher_message = "לא ניתן לשחזר את התרשים באופן אמין — במסמך ישולב השרטוט המקורי."
            rec.review = initial_review(rec, prior_review)
            return _finish(rec, ai_model, source_png)
        warns: list[str] = []
        solved = None
        feats: dict[str, Any] = {}
        detection_ok = False
        t, st = spec.diagram_type, spec.subtype
        if t == "graph" and st == "formula_graph":
            if teacher_spec is None:
                warns += formula_parser.merge_text(spec.graph, question_text, spec.observed.num_curves)
            for c in spec.graph.curves:
                if c.expression and not c.pieces:
                    try:
                        f = feature_detector.features(sm.parse_expression(c.expression), spec.graph.axes.x_min, spec.graph.axes.x_max,
                                                      spec.graph.axes.y_max - spec.graph.axes.y_min)
                        feats[c.id] = f
                        feature_detector.add_computed_holes(spec.graph, c, f)
                    except Exception:
                        pass
        elif t == "graph" and st == "qualitative_graph" and formula_parser.functions_from_text(question_text):
            warns.append("בשאלה מופיעה נוסחה מפורשת — מומלץ לשחזר כגרף נוסחה (הגרף האיכותני אינו ממציא משוואה).")
        elif t == "geometry":
            if teacher_spec is None:
                warns += geometry_parser.merge_text(spec.geometry, question_text)
            else:
                for c in geometry_parser.marks_to_constraints(spec.geometry):
                    if not any(u.type == c.type and sorted(u.points) == sorted(c.points) for u in spec.geometry.constraints):
                        spec.geometry.constraints.append(c)
            solved = _solve_into(spec.geometry, rec, lambda: solve_geometry(spec.geometry))
        elif t == "mixed_graph_geometry":
            if teacher_spec is None:
                warns += mixed_parser.merge_text(spec.mixed, question_text, spec.observed.num_curves)
            solved = _solve_into(spec.mixed.geometry, rec, lambda: mixed_solver.solve(spec.mixed))
        elif t == "chart" and st == "scatter_plot":
            if source_png:
                det = scatter_mod.detect(source_png, spec.scatter.axes)
                rec.validation.info["scatter_detection"] = {"stable": det["stable"], "points": det["points"], "reason": det["reason"]}
                detection_ok = det["stable"] and not scatter_mod.match(spec.scatter.points, det["points"], spec.scatter.axes)
        elif t == "chart" and st != "normal_distribution_schematic" and teacher_spec is None:
            warns += chart_parser.merge_text(spec.chart, question_text)
        spec.evidence = _evidence(spec)
        spec.warnings = list(dict.fromkeys(spec.warnings + warns))
        info = rec.validation.info
        rec.validation = validate(spec, solved)
        rec.validation.info.update(info)
        rec.validation.warnings = list(dict.fromkeys(warns + rec.validation.warnings))
        if feats:
            rec.validation.info["graph_features"] = feats
        if solved is not None:
            rec.validation.info["constraints"] = {"max_residual": solved["max_residual"], "moved_fraction": solved["moved_fraction"]}
        rec.parser_confidence = parser_confidence(spec, solved, policy, detection_confirmed=detection_ok)
        png = None
        manifest: dict = {}
        if rec.validation.ok:
            try:
                _, png, manifest = render_spec(spec)
            except Exception as exc:
                log.exception("render failed for %s", figure_id)
                rec.render_error = f"{type(exc).__name__}: {exc}"
        rec.manifest = manifest
        if rec.validation.ok and not rec.render_error:
            main_feats = next(iter(feats.values()), None) if feats else None
            rec.comparison = compare(spec, manifest, source_png, png, question_text, main_feats)
            if solved is not None and solved["flips"]:
                rec.comparison.critical += [f"שינוי יחס גאומטרי: {f}" for f in solved["flips"]]
        rec.decision = decide(rec.parser_confidence, rec.classifier_confidence, rec.validation, rec.comparison, policy)
        if rec.render_error:
            rec.decision.action = "original"
            rec.decision.reasons.insert(0, "יצירת השרטוט נכשלה.")
        rec.review = initial_review(rec, prior_review)
        rec.teacher_message = _message(rec)
    except Exception as exc:  # one diagram must never break the exam
        log.exception("diagram pipeline failed for %s", figure_id)
        rec.render_error = f"{type(exc).__name__}: {exc}"
        rec.decision = Decision(action="original", reasons=["שחזור השרטוט נכשל."])
        rec.review = ReviewState(status="original")
        rec.teacher_message = "שחזור השרטוט נכשל — במסמך ישולב השרטוט המקורי."
    return _finish(rec, ai_model, source_png)


def _solve_into(geo, rec: DiagramRecord, fn) -> dict | None:
    rec.audit["raw_points"] = {p.id: [p.x, p.y] for p in geo.points}
    ids = [p.id for p in geo.points]
    if len(ids) != len(set(ids)):
        return None
    solved = fn()
    if solved["ok"]:
        for p in geo.points:
            if p.id in solved["points"]:
                p.x, p.y = solved["points"][p.id]
    return solved


def _message(rec: DiagramRecord) -> str:
    a = rec.decision.action
    if a == "original":
        return MSG_ORIGINAL + (" " + rec.decision.reasons[0] if rec.decision.reasons else "")
    if a == "draft":
        return "טיוטת שחזור בביטחון בינוני — נדרשת בדיקה ואישור מורה. עד לאישור ישולב המקור."
    if a == "review":
        return "השחזור עבר את הבדיקות — נדרש אישור מורה. עד לאישור ישולב המקור."
    return "השחזור עבר את כל הבדיקות בביטחון גבוה — עדיין נדרש אישור מורה לפני שילוב במסמך."


def _finish(rec: DiagramRecord, ai_model: str, source_png: bytes | None = None) -> DiagramRecord:
    cleaned_hash = ""
    if source_png:
        try:
            cleaned_hash = cache.PREPROCESS.get_or_compute(cache.key("clean-hash", image_hash(source_png)),
                                                          lambda: image_hash(cleaned_png(source_png)))
        except Exception:
            cleaned_hash = ""
    keep = {k: rec.audit[k] for k in ("raw_points", "input_key", "question_text") if k in rec.audit}
    rec.audit = {**keep, **audit.build(rec, ai_model, cleaned_hash)}
    return rec


def apply_teacher_edit(rec: DiagramRecord, new_spec: DiagramSpec, summary: str, question_text: str,
                       source_png: bytes | None, ai_model: str = "") -> DiagramRecord:
    before = spec_hash(rec.spec)
    review = rec.review.model_copy(deep=True)
    new = process(rec.figure_id, rec.raw_spec_json, question_text, source_png, teacher_spec=new_spec, ai_model=ai_model)
    for k in ("raw_points", "input_key", "question_text"):
        if k in rec.audit:
            new.audit[k] = rec.audit[k]
    new.review.teacher_edits = review.teacher_edits
    add_edit(new.review, summary, before, spec_hash(new.spec))
    return _finish(new, ai_model, source_png)


# ------------------------------------------------------------------ public single-call API
@dataclass
class DiagramResult:
    source_image: bytes
    cleaned_image: bytes
    spec: DiagramSpec | None
    validation: ValidationResult
    comparison: ComparisonResult | None
    decision: Decision
    preview_svg: str | None
    preview_png: bytes | None
    diagnostics: list[str] = field(default_factory=list)
    record: DiagramRecord | None = None


def process_diagram(edited_image: bytes, question_text: str, bbox: list[int] | None = None, question_id: str | int | None = None,
                    figure_id: str | None = None, raw_spec_json: str = "", teacher_context: dict | None = None,
                    ai_model: str = "") -> DiagramResult:
    """The edited (cropped/erased) image is the ONLY image used. bbox = [ymin,xmin,ymax,xmax] in 0..1000."""
    from PIL import Image

    diagnostics: list[str] = []
    source = edited_image
    if bbox and len(bbox) == 4:
        try:
            with Image.open(io.BytesIO(edited_image)) as im:
                W, H = im.size
                y0, x0, y1, x1 = bbox
                buf = io.BytesIO()
                im.convert("RGB").crop((int(x0 * W / 1000), int(y0 * H / 1000), int(x1 * W / 1000), int(y1 * H / 1000))).save(buf, format="PNG")
                source = buf.getvalue()
        except Exception as exc:
            diagnostics.append(f"crop failed: {exc}")
    fid = figure_id or f"q{question_id or 0}f1"
    teacher_spec = (teacher_context or {}).get("spec")
    rec = process(fid, raw_spec_json, question_text, source, ai_model=ai_model, teacher_spec=teacher_spec)
    svg = png = None
    if rec.validation.ok and not rec.render_error and rec.spec is not None:
        try:
            svg, png, _ = render_spec(rec.spec)
        except Exception as exc:
            diagnostics.append(f"render failed: {exc}")
    try:
        cleaned = cleaned_png(source)
    except Exception:
        cleaned = b""
    diagnostics += rec.validation.errors + rec.comparison.critical + rec.comparison.notes
    return DiagramResult(source, cleaned, rec.spec, rec.validation, rec.comparison, rec.decision, svg, png, diagnostics, rec)


def export_bundle(records: dict[str, DiagramRecord], sources: dict[str, bytes]) -> bytes:
    """ZIP with, per figure: source, cleaned source, spec JSON, SVG, PNG, validation, comparison, decision, review, audit."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for fid, rec in records.items():
            base = f"{fid}/"
            src = sources.get(fid)
            if src:
                zf.writestr(base + "source.png", src)
                try:
                    zf.writestr(base + "cleaned.png", cleaned_png(src))
                except Exception:
                    pass
            if rec.spec is not None:
                zf.writestr(base + "spec.json", rec.spec.model_dump_json(indent=2))
                if rec.validation.ok and not rec.render_error:
                    try:
                        svg, png, _ = render_spec(rec.spec)
                        zf.writestr(base + "render.svg", svg)
                        zf.writestr(base + "render.png", png)
                    except Exception:
                        pass
            for name, obj in (("validation", rec.validation), ("comparison", rec.comparison), ("decision", rec.decision), ("review", rec.review)):
                zf.writestr(base + f"{name}.json", obj.model_dump_json(indent=2))
            zf.writestr(base + "audit.json", json.dumps(rec.audit, ensure_ascii=False, indent=2))
    return buf.getvalue()
