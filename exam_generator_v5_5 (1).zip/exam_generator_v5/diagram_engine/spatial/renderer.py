"""Deterministic 3D drawings: isometric cube structures and oblique solids with dimensions, vectors, points on edges."""
from __future__ import annotations

import math

import numpy as np
from matplotlib.patches import Ellipse, FancyArrowPatch
from matplotlib.patches import Polygon as MplPolygon

from ..render_base import INK, export, new_figure
from ..schemas import DiagramSpec
from ..text_utils import visual
from . import solids as S
from . import voxel as V
from .projection import iso, oblique

SHADE = {"top": "#e6e6e6", "left": "#bdbdbd", "front": "#8f8f8f"}


def render(spec: DiagramSpec) -> tuple[str, bytes, dict]:
    sp = spec.spatial
    if sp.voxel is not None and spec.subtype == "voxel_structure":
        return _render_voxel(sp.voxel)
    return _render_solids(spec)


def _render_voxel(v) -> tuple[str, bytes, dict]:
    fig, ax = new_figure(4.8, 4.4)
    ax.set_aspect("equal")
    ax.axis("off")
    if v.plate:
        nx, ny = v.plate
        plate = [iso(-0.3, -0.3, 0), iso(nx + 0.3, -0.3, 0), iso(nx + 0.3, ny + 0.3, 0), iso(-0.3, ny + 0.3, 0)]
        ax.add_patch(MplPolygon(plate, closed=True, facecolor="#9e9e9e", edgecolor=INK, lw=0.8))
    for c in V.draw_order(V.cubes(v)):
        for name, poly in V._faces(*c):
            ax.add_patch(MplPolygon(poly, closed=True, facecolor=SHADE[name], edgecolor=INK, lw=0.8))
    if v.arrow:
        x, y, dx, dy = v.arrow
        ax.add_patch(FancyArrowPatch(iso(x, y, 0), iso(x + dx, y + dy, 0), arrowstyle="-|>", mutation_scale=16, color=INK, lw=2))
    ax.autoscale_view()
    vis = V.visibility(v)
    man = {"total_cubes": V.total(v), "visible_cubes": len(vis["visible"]), "hidden_tops": vis["hidden_tops"],
           "columns": sorted([c.x, c.y, c.height] for c in v.columns), "arrow": v.arrow is not None}
    svg, png = export(fig)
    return svg, png, man


def _render_solids(spec: DiagramSpec) -> tuple[str, bytes, dict]:
    sp = spec.spatial
    fig, ax = new_figure(5.2, 5.0)
    ax.set_aspect("equal")
    ax.axis("off")
    man: dict = {"solids": [], "vertices": [], "edges": 0, "hidden_edges": 0, "dimensions": [], "vectors": [],
                 "points_on_edges": [], "relations": [[r.type, r.a, r.b] for r in sp.relations]}
    all_pts: dict[str, np.ndarray] = {}
    for s in sp.solids:
        man["solids"].append([s.id, s.kind])
        if s.kind in ("cuboid", "polyhedron"):
            verts = S.box_vertices(s)
            P = {k: np.array(oblique(*v)) for k, v in verts.items()}
            all_pts.update(P)
            edges = s.edges or (S.box_edges() if s.kind == "cuboid" else [])
            hidden = {frozenset(e) for e in s.hidden_edges}
            for e in edges:
                dashed = frozenset(e) in hidden
                ax.plot(*zip(P[e[0]], P[e[1]]), color=INK, lw=1.1, linestyle=(0, (4, 3)) if dashed else "-")
                man["edges"] += 1
                man["hidden_edges"] += int(dashed)
            if s.vertices:
                cen = np.mean(list(P.values()), axis=0)
                span = max(np.ptp([p[0] for p in P.values()]), np.ptp([p[1] for p in P.values()]), 1e-6)
                for k, p in P.items():
                    ax.plot([p[0]], [p[1]], "o", color=INK, markersize=2.5)
                    off = (p - cen) / max(1e-9, np.hypot(*(p - cen))) * 0.06 * span
                    ax.text(*(p + off), k, ha="center", va="center", fontsize=11)
                    man["vertices"].append(k)
            if s.face_text:
                front = [P[k] for k in ("D", "C", "C'", "D'") if k in P]
                if len(front) == 4:
                    c = np.mean(front, axis=0)
                    ax.text(c[0], c[1] + 0.15 * (front[2][1] - front[1][1]), visual(s.face_text), ha="center", fontsize=10,
                            bbox=dict(boxstyle="square,pad=0.2", fc="white", ec=INK, lw=0.7))
        elif s.kind == "cylinder":
            r, h = s.dims.get("radius", 1.0), s.dims.get("height", 2.0)
            ox, oy, oz = s.origin
            cx, cy = oblique(ox, oy, oz)
            ry = r * 0.35
            ax.add_patch(Ellipse((cx, cy + h), 2 * r, 2 * ry, fill=False, edgecolor=INK, lw=1.1))
            t = np.linspace(np.pi, 2 * np.pi, 80)
            ax.plot(cx + r * np.cos(t), cy + ry * np.sin(t), color=INK, lw=1.1)
            t2 = np.linspace(0, np.pi, 80)
            ax.plot(cx + r * np.cos(t2), cy + ry * np.sin(t2), color=INK, lw=0.9, linestyle=(0, (4, 3)))
            ax.plot([cx - r, cx - r], [cy, cy + h], color=INK, lw=1.1)
            ax.plot([cx + r, cx + r], [cy, cy + h], color=INK, lw=1.1)
            all_pts[s.id + ".center"] = np.array([cx, cy])
            all_pts[s.id + ".rim"] = np.array([cx + r, cy])
            all_pts[s.id + ".top"] = np.array([cx, cy + h])
            all_pts[s.id + ".left"] = np.array([cx - r, cy])
    for d in sp.dimensions:
        sol = next((s for s in sp.solids if s.id == d.solid), None)
        if sol is None:
            continue
        a, b = _dimension_endpoints(sol, d)
        if a is None:
            continue
        if d.measure == "radius":
            ax.plot(*zip(a, b), color=INK, lw=0.9)
            ax.plot([a[0]], [a[1]], "o", color=INK, markersize=2.5)
            ax.text((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 - 0.08 * max(1.0, sol.dims.get("radius", 1)), visual(d.text), ha="center", va="top", fontsize=10)
        else:
            ax.add_patch(FancyArrowPatch(tuple(a), tuple(b), arrowstyle="<|-|>", mutation_scale=10, color=INK, lw=0.9))
            v = b - a
            n = np.array([v[1], -v[0]]) / max(1e-9, np.hypot(*v))
            ax.text(*((a + b) / 2 + n * 0.08 * max(np.hypot(*v), 1)), visual(d.text), ha="center", va="center", fontsize=10,
                    rotation=math.degrees(math.atan2(v[1], v[0])) if abs(v[0]) > 1e-9 and abs(v[1]) > 1e-9 else (90 if abs(v[0]) < 1e-9 else 0))
        man["dimensions"].append([d.solid, d.measure, d.text])
    for pe in sp.points_on_edges:
        if pe.a in all_pts and pe.b in all_pts:
            p = all_pts[pe.a] + pe.ratio * (all_pts[pe.b] - all_pts[pe.a])
            all_pts[pe.id] = p
            ax.plot([p[0]], [p[1]], "o", color=INK, markersize=3)
            ax.text(p[0] - 0.25, p[1] + 0.15, pe.label if pe.label is not None else pe.id, fontsize=11)
            man["points_on_edges"].append([pe.id, pe.a, pe.b, round(pe.ratio, 9)])
    for vec in sp.vectors:
        if vec.a in all_pts and vec.b in all_pts:
            a, b = all_pts[vec.a], all_pts[vec.b]
            ax.add_patch(FancyArrowPatch(tuple(a), tuple(a + 0.55 * (b - a)), arrowstyle="-|>", mutation_scale=11, color=INK, lw=1.0))
            m = a + 0.55 * (b - a)
            ax.text(m[0] + 0.1, m[1] + 0.12, vec.label, fontsize=11, fontweight="bold")
            man["vectors"].append([vec.a, vec.b, vec.label])
    ax.autoscale_view()
    man["vertices"].sort()
    svg, png = export(fig)
    return svg, png, man


def _dimension_endpoints(sol, d):
    if sol.kind == "cylinder":
        r, h = sol.dims.get("radius", 1.0), sol.dims.get("height", 2.0)
        cx, cy = oblique(*sol.origin)
        if d.measure == "radius":
            return np.array([cx, cy]), np.array([cx + r, cy])
        if d.measure == "diameter":
            return np.array([cx - r, cy - 0.5 * r]), np.array([cx + r, cy - 0.5 * r])
        if d.measure == "height":
            return np.array([cx + r * 1.3, cy]), np.array([cx + r * 1.3, cy + h])
        return None, None
    verts = S.box_vertices(sol)
    P = {k: np.array(oblique(*v)) for k, v in verts.items()}
    if d.edge and all(k in P for k in d.edge):
        a, b = P[d.edge[0]], P[d.edge[1]]
    elif d.measure == "height":
        a, b = P["B"], P["B'"]
        a, b = a + np.array([0.12 * sol.dims.get("width", 1), 0]), b + np.array([0.12 * sol.dims.get("width", 1), 0])
    elif d.measure == "width":
        a, b = P["D"] - np.array([0, 0.1 * sol.dims.get("height", 1) * 0.1]), P["C"] - np.array([0, 0.1 * sol.dims.get("height", 1) * 0.1])
    elif d.measure == "depth":
        shift = np.array([0.1 * sol.dims.get("width", 1), -0.1 * sol.dims.get("width", 1)])
        a, b = P["C"] + shift, P["B"] + shift
    else:
        return None, None
    return a, b
