"""Spatial / 3D: voxel (cube) structures, cuboids, cylinders, polyhedra (box, pyramid) with vectors."""
