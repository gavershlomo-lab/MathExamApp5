"""Backward-compatible shim (v5.4 import path)."""
from .charts.parser import merge_text, values_from_text  # noqa: F401
